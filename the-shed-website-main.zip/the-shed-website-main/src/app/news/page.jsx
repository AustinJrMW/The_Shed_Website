import React from 'react'

const News = () => {
  return (
    <div>News</div>
  )
}

export default News