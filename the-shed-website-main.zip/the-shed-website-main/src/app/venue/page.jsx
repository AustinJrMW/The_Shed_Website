import React from 'react'

const Venue = () => {
  return (
    <div>Venue</div>
  )
}

export default Venue