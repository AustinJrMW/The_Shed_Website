import React from 'react'

const EatDrink = () => {
  return (
    <div>EatDrink</div>
  )
}

export default EatDrink